﻿#ifndef _MATE1PLY_H_
#define _MATE1PLY_H_

#include "../shogi.h"
#ifdef USE_MATE_1PLY

namespace Mate1Ply
{
  // Mate1Ply関係のテーブル初期化
  void init();
}

#endif // MATE_1PLY

#endif // _MATE1PLY_H_
