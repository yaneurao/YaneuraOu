﻿#include "../../shogi.h"
#ifdef MATE_ENGINE

#include <atomic>
#include "../../position.h"

// --- 詰め探索

namespace MateEngine
{

} // end of namespace

#endif
