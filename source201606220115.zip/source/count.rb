Encoding.default_external = 'UTF-8'
require "find"

filenames = []
Find.find(".") { |f|
	if (FileTest.file?(f)) then
		if (f.end_with?(".cpp") || f.end_with?(".h") || f.end_with?(".c") || f.end_with?(".hpp")) then
			filenames.push(f)
		end
	end
}

count1total = 0
count2total = 0
count3total = 0

filenames.each do |filename|
	count1 = 0 # 空行
	count2 = 0 # コメント行
	count3 = 0 # 行数

	print filename 
	File.open(filename) do |file|
		file.each_line do |line|
			count1 = count1 + 1 if /^\s*\n/ =~ line
			count2 = count2 + 1 if /^\s*\/\// =~ line
			count3 = count3 + 1
		end
	end

	print "  空行 : ", count1
	print "  コメント行 : ", count2
	print "  それ以外の行 : ", count3-count1-count2 ,"\n"

	count1total = count1total + count1
	count2total = count2total + count2
	count3total = count3total + count3
	
end

print "空行 : ", count1total ,"\n"
print "コメント行 : ", count2total ,"\n"
print "それ以外の行 : ", count3total-count1total-count2total ,"\n"

gets
